package com.example.springHibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
